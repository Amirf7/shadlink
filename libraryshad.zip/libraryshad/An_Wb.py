class SetClines:
	web = {
		"app_name"    : "Main",
		"app_version" : "3.2.2",
		"platform"    : "Web",
		"package"     : "web.shad.ir",
		"lang_code"   : "fa"
	}

	android = {
		"app_name"    : "Main",
		"app_version" : "2.9.8",
		"platform"    : "Android",
		"package"     : "ir.medu.shad",
		"lang_code"   : "fa"
	}
class Server:
	matnadress = [
			"https://shadmessenger98.iranlms.ir",
			"https://shadmessenger159.iranlms.ir",
			"https://shadmessenger142.iranlms.ir",
			"https://shadmessenger62.iranlms.ir",
			"https://shadmessenger163.iranlms.ir",
			"https://shadmessenger115.iranlms.ir",
			"https://shadmessenger62.iranlms.ir",
			"https://shadmessenger86.iranlms.ir",
			"https://shadmessenger17.iranlms.ir",
			"https://shadmessenger1.iranlms.ir"
			]


	filesadress = [
			"https://shadmessenger98.iranlms.ir",
			"https://shadmessenger159.iranlms.ir",
			"https://shadmessenger142.iranlms.ir",
			"https://shadmessenger62.iranlms.ir",
			"https://shadmessenger163.iranlms.ir",
			"https://shadmessenger115.iranlms.ir",
			"https://shadmessenger62.iranlms.ir",
			"https://shadmessenger86.iranlms.ir",
			"https://shadmessenger17.iranlms.ir",
			"https://shadmessenger1.iranlms.ir"
			]
